$('.circlePage').hover(function () {
    $(this).css({"background-color": "white", "border": "2px solid black", "color": "black"});
}, function () {
    $(this).css({"background-color": "black", "color": "white"});
})

$('.ButtonAssort').hover(function () {
    $(this).css({"background-color": "black", "border": "2px solid black", "color": "white", "cursor": "pointer"});
}, function () {
    $(this).css({"background-color": "white", "color": "black"});
})

$('#CircleP1').click(function () {
    window.location.href = './public/view/assortment.html'
})

$('#CircleP2').click(function () {
    window.location.href = './public/view/aboutUs.html'
})

$('#CircleP3').click(function () {
    window.location.href = '../../index.html'
})